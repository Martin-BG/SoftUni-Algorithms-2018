import java.util.List;

public class KruskalAlgorithm {

    public static List<Edge> kruskal(int numberOfVertices, List<Edge> edges) {
        return null;
    }

    public static int findRoot(int node, int[] parent) {
        return 0;
    }
}
