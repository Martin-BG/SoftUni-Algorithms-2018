﻿using System;

public class EdmondsKarp
{
    public static int FindMaxFlow(int[][] targetGraph)
    {
        throw new NotImplementedException();
    }
}
