﻿using System;
using System.Collections.Generic;

public class ArticulationPoints
{
    public static List<int> FindArticulationPoints(List<int>[] targetGraph)
    {
        throw new NotImplementedException();
    }
}
