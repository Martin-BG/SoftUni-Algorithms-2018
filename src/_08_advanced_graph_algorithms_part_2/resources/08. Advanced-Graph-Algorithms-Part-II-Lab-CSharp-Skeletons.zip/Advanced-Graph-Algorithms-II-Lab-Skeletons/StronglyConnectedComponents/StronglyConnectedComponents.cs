﻿using System;
using System.Collections.Generic;

public class StronglyConnectedComponents
{
    private static List<List<int>> stronglyConnectedComponents;

    public static List<List<int>> FindStronglyConnectedComponents(List<int>[] targetGraph)
    {
        throw new NotImplementedException();
    }
}
